=== LoopPress ===
Contributors: Stephen@swantech.us

Tags: nft, authentication, content protection

Requires at least: 5.0

Tested up to: 6.2

Stable tag: 1.0.4

License: GPL-3.0

Requires PHP: 7.4

License URI: https://www.gnu.org/licenses/gpl-3.0.en.html

Discord: https://discord.gg/gqwrFkwcGg

=== Description ===
LoopPress is a powerful and easy-to-use WordPress plugin that enables users to gate content based on NFT ownership. With LoopPress, you can easily protect your content and offer exclusive access to users who own a specific NFT. LoopPress uses PHP and JS to run directly on your WordPress site's server.

== Frequently Asked Questions ==

Please visit the GitHub Readme -> https://github.com/stepwn/LoopPress