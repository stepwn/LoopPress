<?php
/*
Plugin Name: LoopPress
Plugin URI: https://swantech.us/looppress
Description: Token gate content with Loopring NFTs
Version: 1.1.11
Author: Stephen Swanson
Author URI: https://swantech.us
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// Start the session if it hasn't been started already
if (session_status() == PHP_SESSION_NONE) {
  session_start();
}

// Include integrated plugins
if ( get_option( 'looppress_buddypress_enabled' ) == 1 ) {
    include_once( 'buddypress_integration.php' );
}
if ( get_option( 'looppress_woocommerce_enabled' ) == 1 ) {
    include_once( 'woocommerce_integration.php' );
}

/* function looppress_enqueue_medium_editor() {
    // Enqueue MediumEditor CSS from CDN
    wp_enqueue_style('medium-editor-css', 'https://cdnjs.cloudflare.com/ajax/libs/medium-editor/5.23.3/css/medium-editor.min.css');

    // Enqueue MediumEditor theme CSS (you can choose other themes if you prefer)
    wp_enqueue_style('medium-editor-theme-default', 'https://cdnjs.cloudflare.com/ajax/libs/medium-editor/5.23.3/css/themes/default.min.css');

    // Enqueue MediumEditor JS from CDN
    wp_enqueue_script('medium-editor-js', 'https://cdnjs.cloudflare.com/ajax/libs/medium-editor/5.23.3/js/medium-editor.min.js', array(), false, true);

    // Enqueue your custom JS
    wp_enqueue_script('medium-editor-custom-js', plugins_url('medium-plugin.js', __FILE__), array('medium-editor-js'), false, true);
}
add_action('wp_enqueue_scripts', 'looppress_enqueue_medium_editor'); */


// admin css bug fixes
function enqueue_custom_admin_style() {
    wp_enqueue_style('admin-custom', plugin_dir_url(__FILE__) . 'admin-custom.css', false, '1.0.0');
}
add_action('admin_enqueue_scripts', 'enqueue_custom_admin_style');

function enqueue_font_awesome() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'enqueue_font_awesome');

function walletconnect_enqueue_scripts() {
    // Enqueue plugin script that contains the code to initiate WalletConnect
    // Register the script
    wp_register_script('walletconnect-wordpress', plugin_dir_url(__FILE__) . 'walletconnect.js?v=' . time(), array('jquery'), null, true);
        
    // Add the type attribute as 'module'
    wp_script_add_data('walletconnect-wordpress', 'type', 'module');

    // Enqueue style
    wp_enqueue_style('looppress-style', plugin_dir_url(__FILE__) . 'style.css', array(), filemtime(plugin_dir_path(__FILE__) . 'style.css'), 'all');

    // Dashicons
    wp_enqueue_style('dashicons');
    
    // Add the key to the inline JS code
    $key = uniqid(); // Generate a unique key
    $_SESSION['proxy_key'] = $key; // Save the key to session storage
    // inject the eth address and lrc account id from the session if it exists
	$eth_address = isset($_SESSION['selectedAccount']) ? $_SESSION['selectedAccount'] : '';
	$lrc_account = isset($_SESSION['selectedAccountId']) ? $_SESSION['selectedAccountId'] : '';
	// add walletconnect projectid
    $wc_projectId = esc_attr(get_option('wc_projectId'));
    // plugin directory
    $plugin_dir = plugins_url( '', __FILE__ );
	
    $inline_script = "const looppressKey = '$key';const eth_address = '$eth_address';const wc_projectId = '$wc_projectId'; const plugin_dir = '$plugin_dir'; const lrc_account_id = '$lrc_account';";
    // Add the inline JS code to the file
    wp_add_inline_script('walletconnect-wordpress', $inline_script);
    // Enqueue the script
    wp_enqueue_script('walletconnect-wordpress');
}
add_action('wp_enqueue_scripts', 'walletconnect_enqueue_scripts');

add_action('admin_menu', 'looppress_plugin_menu');
function looppress_plugin_menu() {
    $icon_url = plugins_url('lrc.svg', __FILE__);

    // Add the LoopPress top-level menu
    add_menu_page('LoopPress Plugin', 'LoopPress', 'manage_options', 'looppress', 'looppress_menu_page', $icon_url);

    // Add the Posts submenu under LoopPress
    add_submenu_page('looppress', 'LoopPress NFTs', 'Posts and NFTs', 'manage_options', 'edit.php?post_type=looppress_nft');

     // Add the LoopPress Media submenu under LoopPress
     add_submenu_page('looppress', 'LoopPress Media', 'LoopPress Media', 'manage_options', 'looppress-media', 'looppress_media_page');

    // Add the Settings submenu under LoopPress
    add_submenu_page('looppress', 'LoopPress Settings', 'Settings', 'manage_options', 'looppress-settings', 'looppress_settings_page');

    // Customize the icon size for the top-level menu
    echo '<style>.toplevel_page_looppress .wp-menu-image img { width: 24px; }</style>';

    // Remove the duplicate sub menu item
    remove_submenu_page('looppress', 'LoopPress');
}

function looppress_menu_page(){
    ?>
    <div class="looppress-wrap">
        <h1>Welcome to LoopPress Plugin!</h1>
        <p>Thank you for using LoopPress! This plugin helps you manage and display NFT gated content on your website.</p>
        <p>For more information and updates, please visit:</p>
        <ul>
            <li><a href="https://github.com/stepwn/LoopPress" target="_blank">GitHub Repository</a></li>
            <li><a href="https://discord.gg/GYTEp72SdD" target="_blank">Discord Community</a></li>
            <li><a href="https://looppress.dev" target="_blank">Looppress.dev Website</a></li>
        </ul>
        
        <h2>Plugin Pages</h2>
        <p>You can manage your NFTs and configure settings using the following buttons:</p>
        
        <div class="looppress-plugin-buttons">
            <a class="button-primary" href="<?php echo admin_url('edit.php?post_type=looppress_nft'); ?>">Manage Posts and NFTs</a>
            <a class="button-primary" href="<?php echo admin_url('admin.php?page=looppress-media'); ?>">Manage Protected Media</a>
            <a class="button-primary" href="<?php echo admin_url('admin.php?page=looppress-settings'); ?>">Configure Settings</a>
        </div>
        <br>
        <div style="border:2px solid gray;padding: 16px; width:fit-content;">
        <h3>Keep LoopPress FREE!</h3>
        <p> and support further development by <br>providing a monthly contribution</p>
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="Z2TTMUMFRK5S8">
        <table>
        <tr><td><input type="hidden" name="on0" value="Donation Level">Donation Level</td></tr><tr><td><select name="os0">
            <option value="Supporter">Supporter : $5.00 USD - monthly</option>
            <option value="Hotshot">Hotshot : $15.00 USD - monthly</option>
            <option value="Cool Cat">Cool Cat : $25.00 USD - monthly</option>
            <option value="G.O.A.T">G.O.A.T : $50.00 USD - monthly</option>
            <option value="Competitor's Price">Competitor's Price : $99.00 USD - monthly</option>
        </select> </td></tr>
        </table>
        <input type="hidden" name="currency_code" value="USD">
        <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
        <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
        </form>
        </div>
        <br>
        <hr>
        <h1>Shortcode Usage</h1>
        <div class="looppress-shortcode-info">
            <h2>LoopPress Shortcode: [looppress][/looppress]</h2>
            <p>The <code>[looppress][/looppress]</code> shortcode allows you to show content only to specific NFT owners.</p>
            <p>If any of the provided attributes match the attributes of a user's owned Loopring NFTs, the content inside the shortcode will be displayed. Otherwise, the content will not be served.</p>
            
            <div class="looppress-shortcode-example">
                <h3>Usage:</h3>
                <pre><code>[looppress nft="0xabc123" minter="0xabc123" contract="0xabc123"]Your content here[/looppress]</code></pre>
                * Only one of the nft, minter, or contract attributes needs to be set to work. If multiple are set it will only allow access if all the conditions are true.
                <pre><code>[looppress nft="0xabc123"]Your content here[/looppress]</code></pre>
            </div>
        </div>
        <div class="looppress-shortcode-info">
        <h2>LoopPress Media Shortcode: [looppress_media]</h2>
            <p>The <code>[looppress_media]</code> shortcode allows you to selectively embed/stream protected media (.mp4, .mp3, .jpg, etc).</p>
            <p>First, upload your protected media file <a class="button-primary" href="<?php echo admin_url('admin.php?page=looppress-media'); ?>">Manage Protected Media</a></p>
        
            <div class="looppress-shortcode-example">
                <h3>Usage:</h3>
                <pre><code>[looppress_media type="video" src="https://yoursite.com/wp-content/plugins/LoopPress/protected-content/your-file.mp4"]</code></pre>
                * Copy the full link to the protected file into the <code>src=""</code> attribute.<br>
                * Use the <code>type=""</code> attribute to your media type: image, video, or audio.
                <p>LoopPress will stream the embedded media</p>
            </div>
        </div>
        <div class="looppress-shortcode-info">
        <h2>LoopPress Media Download Shortcode: [looppress_media_download]</h2>
            <p>The <code>[looppress_media_download]</code> shortcode allows you to selectively serve protected media (.mp4, .zip, .webm, .obj, etc).</p>
            <p>First, upload your protected media file <a class="button-primary" href="<?php echo admin_url('admin.php?page=looppress-media'); ?>">Manage Protected Media</a></p>
        
            <div class="looppress-shortcode-example">
                <h3>Usage:</h3>
                <pre><code>[looppress_media_download src="https://yoursite.com/wp-content/plugins/LoopPress/protected-content/your-file.zip"]</code></pre>
                * Copy the full link to the protected file into the <code>src=""</code> attribute.<br>
                * Use the <code>text="Download Button Text"</code> attribute to change the download button text.
                <p>LoopPress will display a download button to serve the protected media file</p>
            </div>
        </div>
    </div>
    <style>
        .looppress-plugin-buttons {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .looppress-shortcode-info {
            margin-top: 30px;
            border: 1px solid #ccc;
            padding: 15px;
            background-color: #f9f9f9;
        }
        .looppress-shortcode-example {
            margin-top: 15px;
            border-top: 1px dashed #ccc;
            padding-top: 15px;
        }
    </style>
    <?php
}

function looppress_nft_custom_post_type() {
    register_post_type('looppress_nft', array(
        'labels' => array(
            'name' => 'LoopPress NFTs',
            'singular_name' => 'LoopPress NFT',
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-images-alt2', // Set a custom menu icon
        'rewrite' => array('slug' => 'looppress-nfts'), // Custom permalink structure
        'taxonomies' => array('category'), // You can add more taxonomies here
        'has_archive' => true, // Enable archive page
        'show_in_menu' => false,
    ));
}
add_action('init', 'looppress_nft_custom_post_type');

function looppress_custom_post_template($template) {
    if (is_singular('looppress_nft')) {
        ob_start();
        include(plugin_dir_path(__FILE__) . 'single-looppress_nft.php');
        $content = ob_get_clean();
        wp_head();
        echo $content;
        wp_footer();
        return '';
    }
    return $template;
}
add_filter('template_include', 'looppress_custom_post_template');


// gated dowloadable media handling

// Function to create the protected-folder and .htaccess file
function looppress_create_protected_folder() {
    $protected_folder_path = plugin_dir_path(__FILE__) . 'protected-folder/';
    $htaccess_content = "# Deny all access from outside\n"
                    ."Order deny,allow\n"
                    ."Deny from all\n";

    if (!file_exists($protected_folder_path)) {
        // Create the protected folder
        mkdir($protected_folder_path, 0755, true);

        // Create and write the .htaccess file
        $htaccess_file_path = $protected_folder_path . '.htaccess';
        file_put_contents($htaccess_file_path, $htaccess_content);
    }
}

// Hook the function to plugin activation
register_activation_hook(__FILE__, 'looppress_create_protected_folder');


function looppress_embed_protected_media($atts) {
    $atts = shortcode_atts(array(
        'src' => '',
        'text' => 'Download' // Default text is "Download"
    ), $atts);

    // Add access checks here to ensure only authorized users can access the media
    $file_url = $atts['src'];
    $file_name = basename($file_url);
    $button_text = esc_attr($atts['text']); // Sanitize and use the provided text

    $nonce = wp_create_nonce('looppress_download_' . $file_name);

    return "<a class='looppress-download-button' href='" . admin_url('admin-ajax.php?action=looppress_serve_protected_file&file=' . urlencode($file_url) . '&nonce=' . $nonce) . "' download><button class='wp-block-button__link wp-element-button'>$button_text</button></a>";
}
add_shortcode('looppress_media_download', 'looppress_embed_protected_media');



function looppress_serve_protected_file() {
    if (isset($_GET['file']) && isset($_GET['nonce']) && wp_verify_nonce($_GET['nonce'], 'looppress_download_' . basename($_GET['file']))) {
        $file_url = sanitize_text_field($_GET['file']); // Get the full file URL
        $file_name = basename(parse_url($file_url, PHP_URL_PATH)); // Extract the file name

        $protected_folder_path = plugin_dir_path(__FILE__) . 'protected-folder/';
        $file_path = $protected_folder_path . $file_name;
        
        if (file_exists($file_path)) {
            $mime_type = mime_content_type($file_path);

            header('Content-Type: ' . $mime_type);
            header('Content-Disposition: attachment; filename="' . $file_name . '"');
            readfile($file_path);
            exit;
        } else {
            http_response_code(404);
            echo 'File not found, ' . $file_path;
            exit;
        }
    } else {
        http_response_code(400);
        echo 'Unauthorized access';
        exit;
    }
}
add_action('wp_ajax_looppress_serve_protected_file', 'looppress_serve_protected_file');
add_action('wp_ajax_nopriv_looppress_serve_protected_file', 'looppress_serve_protected_file');

function looppress_stream_protected_media() {
    $file_url = isset($_GET['file']) ? sanitize_text_field($_GET['file']) : '';

    if (!$file_url || !isset($_GET['nonce']) || !wp_verify_nonce($_GET['nonce'], 'looppress_stream_' . basename($file_url))) {
        http_response_code(400);
        echo 'Unauthorized access';
        exit;
    }

    // Extract the filename from the provided URL
    $file_name = basename(parse_url($file_url, PHP_URL_PATH));

    $file_path = plugin_dir_path(__FILE__) . 'protected-folder/' . $file_name;

    if (!file_exists($file_path)) {
        die('File not found.');
    }

    $chunkSize = 15 * 1024 * 1024; // Stream in 15MB chunks
    $handle = fopen($file_path, 'rb');

    $fileSize = filesize($file_path);
    $length = $fileSize; // Total length
    $start = 0; // Start byte
    $end = $fileSize - 1; // End byte

    header('Content-Type: ' . mime_content_type($file_path));
    header("Accept-Ranges: bytes");
    header("Content-Length: " . $length);

    while (!feof($handle) && ($p = ftell($handle)) <= $end) {
        if ($p + $chunkSize > $end) {
            $chunkSize = $end - $p + 1;
        }
        set_time_limit(0); // Reset time limit for big files
        echo fread($handle, $chunkSize);
        flush(); // Free up memory
    }

    fclose($handle);
    exit;
}
add_action('wp_ajax_looppress_stream_protected_media', 'looppress_stream_protected_media');
add_action('wp_ajax_nopriv_looppress_stream_protected_media', 'looppress_stream_protected_media');

function looppress_stream_media_shortcode($atts) {
    $a = shortcode_atts(array(
        'type' => 'image', // default type is video, can be changed to audio or image
        'src' => '' // the full URL of the media
    ), $atts);

    $nonce = wp_create_nonce('looppress_stream_' . basename($a['src']));

    $output = '';

    if ($a['type'] === 'video') {
        $output .= '<video controls width="100%">';
        $output .= '<source src="' . admin_url('admin-ajax.php') . '?action=looppress_stream_protected_media&file=' . urlencode($a['src']) . '&nonce=' . $nonce . '" type="video/mp4">';
        $output .= 'Your browser does not support the video tag.';
        $output .= '</video>';
    } elseif ($a['type'] === 'audio') {
        $output .= '<audio controls>';
        $output .= '<source src="' . admin_url('admin-ajax.php') . '?action=looppress_stream_protected_media&file=' . urlencode($a['src']) . '&nonce=' . $nonce . '" type="audio/mp3">';
        $output .= 'Your browser does not support the audio element.';
        $output .= '</audio>';
    } elseif ($a['type'] === 'image') {
        $output .= '<img width="100%"src="' . admin_url('admin-ajax.php') . '?action=looppress_stream_protected_media&file=' . urlencode($a['src']) . '&nonce=' . $nonce . '" alt="Protected Image">';
    }

    return $output;
}
add_shortcode('looppress_media', 'looppress_stream_media_shortcode');


function looppress_media_page() {
    if (!current_user_can('upload_files')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    // Handle file deletions
    if (isset($_GET['delete']) && !empty($_GET['file'])) {
        $protected_folder_path = plugin_dir_path(__FILE__) . 'protected-folder/';
        $file_name = sanitize_file_name($_GET['file']);
        $file_path = $protected_folder_path . $file_name;
        
        if (file_exists($file_path)) {
            unlink($file_path); // Delete the file
            echo '<div class="notice notice-success"><p>File deleted successfully!</p></div>';
        }
    }
    
    // Handle media uploads
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_FILES)) {
        $protected_folder_path = plugin_dir_path(__FILE__) . 'protected-folder/';
        
        // Create the protected folder if it doesn't exist
        if (!file_exists($protected_folder_path)) {
            mkdir($protected_folder_path, 0755, true);
        }
        
        $file = $_FILES['file'];
        $file_path = $protected_folder_path . $file['name'];
        
        // Move the uploaded file to the protected folder
        if (move_uploaded_file($file['tmp_name'], $file_path)) {
            echo '<div class="notice notice-success"><p>File uploaded successfully!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Error uploading file.</p></div>';
        }
    }
    
    // Display media upload form
    echo '<div class="looppress-wrap">';
    echo '<h1>LoopPress Media</h1>';
    echo '<p>Welcome to the LoopPress Media dashboard. Here, you can easily upload and manage your media files. Follow the instructions below to get started:</p>';
    
    echo '<h2>Upload Media</h2>';
    echo '<p>Select a file from your device and click "Upload" to add it to your LoopPress Media library.</p>';
    echo '<form method="POST" enctype="multipart/form-data">';
    echo '<input type="file" name="file">';
    echo '<input type="submit" value="Upload" class="button button-primary">';
    echo '</form>';
    
    echo '<h2>Uploaded Files</h2>';
    echo '<p>Below is a list of your uploaded files. You can copy the URL or shortcode for embedding, or delete files as needed.</p>';
    
    $protected_folder_path = plugin_dir_path(__FILE__) . 'protected-folder/';
    $files = scandir($protected_folder_path);
    
    if (!empty($files)) {
        echo '<ul>';
        foreach ($files as $file) {
            if ($file != '.' && $file != '..' && $file != '.htaccess') {
                $file_url = plugin_dir_url(__FILE__) . 'protected-folder/' . urlencode($file);
                echo '<li>' . $file . ' - <button class="copy-url-button" data-url="' . $file_url . '">Copy URL</button> - <a href="?page=looppress-media&delete=true&file=' . urlencode($file) . '" class="delete-button" onclick="return confirm(\'Are you sure you want to delete this file?\')">Delete</a></li>';
            }
        }
        echo '</ul>';
    } else {
        echo '<p>No files uploaded.</p>';
    }
    
    echo '</div>'; // End of wrap div

    // JavaScript for copying URL and shortcode to clipboard
    echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            const copyUrlButtons = document.querySelectorAll(".copy-url-button");
            const copyShortcodeButtons = document.querySelectorAll(".copy-shortcode-button");
            
            copyUrlButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const url = button.getAttribute("data-url");
                    copyToClipboard(url);
                    alert("URL copied to clipboard: " + url);
                });
            });
            
            copyShortcodeButtons.forEach(button => {
                button.addEventListener("click", function() {
                    const shortcode = button.getAttribute("data-shortcode");
                    copyToClipboard(shortcode);
                    alert("Shortcode copied to clipboard:\\n" + shortcode);
                });
            });
            
            function copyToClipboard(text) {
                const textarea = document.createElement("textarea");
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand("copy");
                document.body.removeChild(textarea);
            }
        });
    </script>';
}




// Add custom meta box to select layout style
function looppress_add_layout_style_meta_box() {
    add_meta_box(
        'looppress_layout_style_meta_box',
        'Layout Style',
        'looppress_render_layout_style_meta_box',
        'looppress_nft', // You can change this to other post types if needed
        'normal', // Position of the meta box
        'default'
    );
}
add_action('add_meta_boxes', 'looppress_add_layout_style_meta_box');

// Render the content of the custom meta box
function looppress_render_layout_style_meta_box($post) {
    $layout_style = get_post_meta($post->ID, 'looppress_layout_style', true);

    // Define layout options
    $layout_options = array(
        'two-column' => 'Two-Column',
        'stacked' => 'Stacked',
    );

    // Output the radio buttons
    foreach ($layout_options as $value => $label) {
        echo '<label>';
        echo '<input type="radio" name="looppress_layout_style" value="' . esc_attr($value) . '" ' . checked($layout_style, $value, false) . '>';
        echo ' ' . esc_html($label); // Add a space before the label
        echo '</label><br>';
    }
}

// Save the selected layout style when the post is saved or updated
function looppress_save_layout_style_meta_box($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['looppress_layout_style'])) {
        $layout_style = sanitize_key($_POST['looppress_layout_style']);
        update_post_meta($post_id, 'looppress_layout_style', $layout_style);
    }
}
add_action('save_post', 'looppress_save_layout_style_meta_box');

// Add custom meta fields to LoopPress NFTs
function looppress_nft_meta_fields() {
    add_meta_box(
        'looppress_nft_meta',
        'LoopPress NFT Details',
        'looppress_nft_meta_callback',
        'looppress_nft',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'looppress_nft_meta_fields');

// Callback function for rendering meta box content
function looppress_nft_meta_callback($post) {
    // Add nonce for security and authentication
    wp_nonce_field('looppress_nft_nonce', 'looppress_nft_nonce');

    // Get existing values from the database
    $nft_id = get_post_meta($post->ID, 'looppress_nft_id', true);
    $minter = get_post_meta($post->ID, 'looppress_minter', true);
    $token = get_post_meta($post->ID, 'looppress_token', true);
    $contract = get_post_meta($post->ID, 'looppress_contract', true);
    $desc = get_post_meta($post->ID, 'looppress_short_description', true);

    // Render the fields
    echo '<label for="looppress_nft_id">LoopPress NFT ID:</label>';
    echo '<input type="text" id="looppress_nft_id" name="looppress_nft_id" value="' . esc_attr($nft_id) . '"><br>';

    echo '<label for="looppress_minter">LoopPress Minter:</label>';
    echo '<input type="text" id="looppress_minter" name="looppress_minter" value="' . esc_attr($minter) . '"><br>';

    echo '<label for="looppress_contract">LoopPress Contract:</label>';
    echo '<input type="text" id="looppress_contract" name="looppress_contract" value="' . esc_attr($token) . '"><br>';

    echo '<label for="looppress_short_description">LoopPress Short Description:</label>';
    echo '<input type="text" id="looppress_short_description" name="looppress_short_description" value="' . esc_attr($desc) . '"><br>';
}

// Save custom meta fields
function save_looppress_nft_meta($post_id) {
    // Check if nonce is set
    if (!isset($_POST['looppress_nft_nonce'])) {
        return;
    }

    // Verify nonce
    if (!wp_verify_nonce($_POST['looppress_nft_nonce'], 'looppress_nft_nonce')) {
        return;
    }

    // Check if the current user has permission to save
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    // Sanitize and save the data
    if (isset($_POST['looppress_nft_id'])) {
        update_post_meta($post_id, 'looppress_nft_id', sanitize_text_field($_POST['looppress_nft_id']));
    }
    if (isset($_POST['looppress_minter'])) {
        update_post_meta($post_id, 'looppress_minter', sanitize_text_field($_POST['looppress_minter']));
    }
    if (isset($_POST['looppress_token'])) {
        update_post_meta($post_id, 'looppress_token', sanitize_text_field($_POST['looppress_token']));
    }
    if (isset($_POST['looppress_contract'])) {
        update_post_meta($post_id, 'looppress_contract', sanitize_text_field($_POST['looppress_contract']));
    }
    if (isset($_POST['looppress_short_description'])) {
        update_post_meta($post_id, 'looppress_short_description', sanitize_text_field($_POST['looppress_short_description']));
    }
}
add_action('save_post_looppress_nft', 'save_looppress_nft_meta');



// Looppress Settings
add_action('admin_init', 'looppress_settings_init');
function looppress_settings_init() {
    register_setting('looppress_settings', 'loopring_api_key');
	register_setting('looppress_settings', 'wc_projectId');
    register_setting('looppress_settings', 'allow_unregistered_users');
    register_setting('looppress_settings', 'nft_roles');
    register_setting('looppress_settings', 'looppress_default_fail_message', ['default' => "<span class='dashicons dashicons-lock' style='font-size: 2.5em; width: 2.5em; display: block; margin: auto; box-sizing: border-box;'></span><br><b>You do not own the required NFT to view this content.</b><br><small>If you recently acquired the NFT, it may take up to 30 minutes for the transaction to post and be available.</small>"]);
    register_setting('looppress_settings', 'looppress_add_accountButton_to_fail', ['default' => 0]);
    register_setting('looppress_settings', 'nft_roles_enabled', ['default' => 0]);
    register_setting('looppress_settings', 'looppress_nft_enabled', ['default' => 1]);
    register_setting('looppress_settings', 'looppress_buddypress_enabled', ['default' => 0]);
    register_setting('looppress_settings', 'looppress_woocommerce_enabled', ['default' => 0]);
    register_setting('looppress_settings', 'default_nft_role', ['default' => get_option('default_role')]);
}

function looppress_settings_page() {
    // Check if WalletConnect project ID and Loopring API key are not set
    $walletconnect_project_id = get_option('wc_projectId');
    $loopring_api_key = get_option('loopring_api_key');
    
    // Display a notification if either value is not set
    if (empty($walletconnect_project_id) || empty($loopring_api_key)) {
        echo '<div class="notice notice-error"><p><strong>LoopPress Plugin:</strong> Please set your <b>WalletConnect project ID</b> and <b>Loopring API key</b> in the settings to enable full functionality.</p></div>';
    }
    ?>
    <style>
    .looppress-wrap h2 {
        color: #333;
        padding-bottom: 10px;
        margin: 20px 0;
        border-bottom: 1px solid #cccccc;
    }
    .looppress-wrap .form-table th {
        font-weight: 600;
    }
    .looppress-wrap input[type="text"], .looppress-wrap input[type="password"] {
        width: 60%;
    }
    .looppress-wrap .nft-role-section div {
        margin-bottom: 10px;
    }
    </style>
    <div class="looppress-wrap">
        <h1>LoopPress Plugin Settings</h1>
        <form method="post" action="options.php">
            <?php settings_fields('looppress_settings'); ?>
            <?php do_settings_sections('looppress_settings'); ?>

            <h2>General Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="loopring_api_key">Loopring API Key</label></th>
                    <td><input type="password" id="loopring_api_key" name="loopring_api_key" value="<?php echo esc_attr(get_option('loopring_api_key')); ?>" /></td>
                </tr>
                <tr>
                    <th scope="row"><label for="wc_projectId">WalletConnect Project ID</label></th>
                    <td><input type="text" id="wc_projectId" name="wc_projectId" value="<?php echo esc_attr(get_option('wc_projectId')); ?>" /></td>
                </tr>
                <tr>
                <th scope="row">
                    <label for="looppress_default_fail_message">Default Fail Message HTML</label>
                    </th>
                    <td>
                        <textarea id="looppress_default_fail_message" name="looppress_default_fail_message" rows="4" cols="50"><?php echo esc_textarea(get_option('looppress_default_fail_message', "<span class='dashicons dashicons-lock' style='font-size: 2.5em; width: 2.5em; display: block; margin: auto; box-sizing: border-box;'></span><br><b>You do not own the required NFT to view this content.</b><br><small>If you recently acquired the NFT, it may take up to 30 minutes for the transaction to post and be available.</small>")); ?></textarea>
                    </td>
                    <td>
                        Specify the default message to be displayed when access is denied due to NFT ownership verification failure.
                    </td>
                </tr>
                <tr>
                <th scope="row"><label for="looppress_add_accountButton_to_fail">Add Account button to fail messages</label></th>
                <td><input type="checkbox" id="looppress_add_accountButton_to_fail" name="looppress_add_accountButton_to_fail" value="1" <?php checked(1, get_option('looppress_add_accountButton_to_fail', 1), true); ?> /></td>
                <td>Add the Account/wallet button to failed gate messages by default</td>
                </tr>
                <tr>
                <th scope="row"><label for="looppress_nft_enabled">Enable LoopPress NFT Posts</label></th>
                <td><input type="checkbox" id="looppress_nft_enabled" name="looppress_nft_enabled" value="1" <?php checked(1, get_option('looppress_nft_enabled', 1), true); ?> /></td>
                <td>Enable or disable LoopPress NFT posts.</td>
                </tr>
                <tr>
                <th scope="row"><label for="looppress_buddypress_enabled">Enable LoopPress NFT Groups in BuddyPress</label></th>
                <td><input type="checkbox" id="looppress_buddypress_enabled" name="looppress_buddypress_enabled" value="1" <?php checked(1, get_option('looppress_buddypress_enabled', 1), true); ?> /></td>
                <td>Enable or disable LoopPress integration with BuddyPress.</td>
                </tr>
                <tr>
                <th scope="row"><label for="looppress_woocommerce_enabled">Enable LoopPress integration with WooCommerce</label></th>
                <td><input type="checkbox" id="looppress_woocommerce_enabled" name="looppress_woocommerce_enabled" value="1" <?php checked(1, get_option('looppress_woocommerce_enabled', 1), true); ?> /></td>
                <td>Enable or disable LoopPress integration with WooCommerce.</td>
                </tr>
            </table>

            <h2>User Settings</h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="allow_unregistered_users">Allow Unregistered Users</label></th>
                    <td><input type="checkbox" id="allow_unregistered_users" name="allow_unregistered_users" value="1" <?php checked(1, get_option('allow_unregistered_users'), true); ?> /></td>
                    <td>Allow users who are not logged in to WordPress to use token gating</td>
                </tr>
                <tr>
                    <th scope="row"><label for="nft_roles_enabled">Enable NFT Roles</label></th>
                    <td><input type="checkbox" id="nft_roles_enabled" name="nft_roles_enabled" value="1" <?php checked(1, get_option('nft_roles_enabled'), true); ?> /></td>
                    <td>Enable Wordpress Role Modification based on NFT ownership if the user is logged in to WordPress</td>
                </tr>

                <tr>
                    <th scope="row"><label for="default_nft_role">Default NFT Role</label></th>
                    <td>
                        <select id="default_nft_role" name="default_nft_role">
                        <?php 
                        global $wp_roles;
                        $all_roles = array_reverse($wp_roles->roles);
                        $default_nft_role = get_option('default_nft_role', '');
                        foreach ($all_roles as $role_name => $role_info): 
                        ?>
                            <option value="<?php echo strtolower($role_name); ?>" <?php selected(strtolower($role_name), strtolower($default_nft_role));?>><?php echo $role_info['name']; ?></option>
                        <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                
            </table>


            <style>
            .looppress-role-inputs {
                display: none;
            }
            .looppress-role-label {
                cursor: pointer;
            }
            </style>

            <h2>NFT Role Settings <br><small>(click role for dropdown)</small></h2>
            <div class="nft-role-section">
                <table class="form-table">
                    <?php 
                    global $wp_roles;
                    $all_roles = $wp_roles->roles;
                    $nft_roles = get_option('nft_roles', []);
                    foreach ($all_roles as $role_name => $role_info): 
                        $role_attributes = isset($nft_roles[$role_name]) ? $nft_roles[$role_name] : ['minter' => '', 'token' => '', 'nft_id' => ''];
                    ?>
                        <tr class="role-row">
                            <th scope="row" class="looppress-role-label"><?php echo $role_info['name']; ?> </th>
                            <td class="looppress-role-inputs">
                                <div>
                                    <label for="nft_role_<?php echo $role_name; ?>_minter">Minter</label>
                                    <input type="text" id="nft_role_<?php echo $role_name; ?>_minter" name="nft_roles[<?php echo $role_name; ?>][minter]" value="<?php echo $role_attributes['minter']; ?>" />
                                </div>
                                <div>
                                    <label for="nft_role_<?php echo $role_name; ?>_token">Token</label>
                                    <input type="text" id="nft_role_<?php echo $role_name; ?>_token" name="nft_roles[<?php echo $role_name; ?>][token]" value="<?php echo $role_attributes['token']; ?>" />
                                </div>
                                <div>
                                    <label for="nft_role_<?php echo $role_name; ?>_nft_id">NFT ID</label>
                                    <input type="text" id="nft_role_<?php echo $role_name; ?>_nft_id" name="nft_roles[<?php echo $role_name; ?>][nft_id]" value="<?php echo $role_attributes['nft_id']; ?>" />
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <script>
            jQuery(document).ready(function($) {
                $('.role-row .role-label').click(function() {
                    $(this).siblings('.role-inputs').slideToggle();
                });
            });
            </script>


            <?php submit_button(); ?>

        </form>
    </div>
    <?php
}

function looppress_disconnect_shortcode() {
    ob_start(); // Start output buffering
    ?>
    <button style="display:block; margin:auto; width:fit-content;" class="wp-block-button__link wp-element-button"  id="btn-disconnect-manual">Disconnect Web3</button>
    <?php
    return ob_get_clean(); // Return the buffered content as a string
}
add_shortcode('looppress_disconnect', 'looppress_disconnect_shortcode');



function looppress_dashboard_shortcode($atts) {
    $text = isset($atts['text']) ? $atts['text'] : "Web3 Wallet";
    $redir = isset($atts['redir']) ? $atts['redir'] : false;
    ob_start();
    ?>
    <button id="show-modal-button" onclick="document.getElementById('web3-modal').style.display = 'block';" style="display:block;margin:auto;width:fit-content;" class="wp-block-button__link wp-element-button has-text-color looppressButton"><?php echo $text; ?></button>
    <script>
        // Check if the connect-wallet-section already exists on the page
        var existingConnectWalletSection = document.getElementById('connect-wallet-section');
        if (!existingConnectWalletSection) {// If the connect-wallet-section doesn't exist, add it
            document.write(`
                <div id="connect-wallet-section">
                    <div id="web3-modal">
                        <div id="looppress-modal-contents">
                            <button id="close-modal-button" style="position: absolute; top: 10px; right: 10px;">Close</button>
                            <?php
                            if (!isset($_SESSION['selectedAccount']) && !isset($_SESSION['selectedAccountId'])) {
                                ?>
                                <div style="text-align:center;">
                                    <img src="<?php echo plugin_dir_url(__FILE__) . 'eth.png'; ?>" alt="ETH logo" style="width:24px">
                                    <img src="<?php echo plugin_dir_url(__FILE__) . 'lrc.png'; ?>" alt="LRC logo" style="width:24px">
                                    <img src="<?php echo plugin_dir_url(__FILE__) . 'wp.ico'; ?>" alt="WordPress logo" style="width:24px">
                                </div>
                                <div id="prepare">
                                    <span id="loading">Loading LoopPress...</span>
                                    <button id="btn-connect" redirect="<?php echo $redir;?>" style="display:block;margin:auto;width:fit-content;" class="wp-block-button__link wp-element-button looppressButton">Log in Web3</button>
                                </div>
                                <div id="connected" style="display:none;">
                                    <p>Connected to <span id="network-name"></span> network with account:</p>
                                    <p id="selected-account" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-size: 14px; max-width: 100%;"></p>
                                    <p id="account-balance"></p>
                                    Loopring ID: <p id="loopring-account-ID"></p>
                                    <button style="display:block; margin:auto; width:fit-content;" class="wp-block-button__link wp-element-button looppressButton" id="btn-disconnect">Disconnect</button>
                                </div>


                                <?php
                            } else {
                                ?>
                                <div style="text-align:center;">
                                    <img src="<?php echo plugin_dir_url(__FILE__) . 'eth.png'; ?>" alt="ETH logo" style="width:24px">
                                    <img src="<?php echo plugin_dir_url(__FILE__) . 'lrc.png'; ?>" alt="LRC logo" style="width:24px">
                                    <img src="<?php echo plugin_dir_url(__FILE__) . 'wp.ico'; ?>" alt="WordPress logo" style="width:24px">
                                </div>
                                <div id="prepare">
                                    <span id="loading">Loading LoopPress...</span>
                                    <button id="btn-connect" isLoggedIn="True" style="display:block;margin:auto;width:fit-content;" class="wp-block-button__link wp-element-button looppressButton">Log in Web3</button>
                                </div>
                                <div id="connected" style="display:none;">
                                    <p>Connected to <span id="network-name"></span> network with account:</p>
                                    <p id="selected-account"></p>
                                    <p id="account-balance"></p>
                                    Loopring ID: <p id="loopring-account-ID"></p>
                                    <button style="display:block;margin:auto;width:fit-content;" class="wp-block-button__link wp-element-button looppressButton" id="btn-disconnect">Disconnect</button>
                                </div>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            `);
        }
    </script>
    <script>document.getElementById('close-modal-button').addEventListener('click', function() {document.getElementById('web3-modal').style.display = 'none';});</script>
    <?php
    return ob_get_clean();
}



function looppress_register_shortcode() {
  add_shortcode('looppress_dashboard', 'looppress_dashboard_shortcode');
  add_shortcode('looppress_button', 'looppress_dashboard_shortcode');
}
add_action('init', 'looppress_register_shortcode');

add_shortcode('looppress', 'looppress_membership_shortcode');
add_shortcode('looppress_required', 'looppress_membership_shortcode'); // backwards compatible but depreciated
add_shortcode('looppress_inner', 'looppress_membership_shortcode');
add_shortcode('looppress_inner2', 'looppress_membership_shortcode');
add_shortcode('looppress_inner3', 'looppress_membership_shortcode');
add_shortcode('looppress_inner4', 'looppress_membership_shortcode');
add_shortcode('looppress_inner5', 'looppress_membership_shortcode');
// ... continue as needed

function looppress_shortcode($content = "",$fail_message = "") {
	$redir = false;
	if($content != ""){
		$redir = true;
	}
    if(!isset($_SESSION['selectedAccount'])&&!isset($_SESSION['selectedAccountId'])){
    // Only display contents if user is logged in
        return do_shortcode("[looppress_button]");
    }
    else{
        $html = '<p class="looppress_fail_message">'.$fail_message;
        if(get_option("looppress_add_accountButton_to_fail") == 1){
            $dashboard_shortcode = do_shortcode('[looppress_dashboard]'); // Adding the shortcode here
            $html .= $dashboard_shortcode;
        }
        return $html.'</p>';
    }
}

function looppress_membership_shortcode( $atts, $content = null ) {
    $redir = false;
    if ( $content != "" ) {
        $redir = true;
    }

    // Check if no attributes are passed, then set default post metadata
    if ( empty( $atts ) ) {
        $post_id = get_the_ID(); // Get the current post ID
        $nft_id_from_metadata = get_post_meta( $post_id, 'looppress_nft_id', true );
        if($nft_id_from_metadata){
            $atts = array( 'nft_id' => $nft_id_from_metadata );
        }
        $nft_minter_from_metadata = get_post_meta( $post_id, 'looppress_minter', true );
        if($nft_minter_from_metadata){
            $atts = array( 'minter' => $nft_minter_from_metadata );
        }
        $nft_token_from_metadata = get_post_meta( $post_id, 'looppress_token', true );
        if($nft_token_from_metadata){
            $atts = array( 'token' => $nft_token_from_metadata );
        }
        $nft_contract_from_metadata = get_post_meta( $post_id, 'looppress_contract', true );
        if($nft_contract_from_metadata){
            $atts = array( 'contract' => $nft_contract_from_metadata );
        }
    }

    if ( ! isset( $_SESSION['selectedAccount'] ) && ! isset( $_SESSION['selectedAccountId'] ) ) {
        // Only display contents if user is logged in
        return do_shortcode('[looppress_button redir="'.$redir.'" text="Unlock Content"]');
    }

    // Extract attributes
    $attributes = shortcode_atts( [ 'contract' => '', 'token' => '', 'minter' => '', 'nft_id' => '', 'schedule' => '' ], $atts );

    // Check for schedule attribute and parse it if present
    if ( isset( $attributes['schedule'] ) && !empty( $attributes['schedule'] ) ) {
        $schedule_logic = json_decode( str_replace( "'", '"', $attributes['schedule'] ), true );
        if ( json_last_error() == JSON_ERROR_NONE && is_array( $schedule_logic ) ) {
            // Get the current date
            $current_date = new DateTime();
            $applicable_logic = null;

            // Iterate through the schedule logic and find the most recent applicable logic
            foreach ( $schedule_logic as $date => $logic ) {
                $schedule_date = DateTime::createFromFormat('Y-m-d H:i', $date);
                if ( $schedule_date <= $current_date ) {
                    $applicable_logic = $logic;
                } else {
                    break; // Since the logic is ordered, we can break early
                }
            }

            // If applicable logic is found, override the respective attributes
            if ( $applicable_logic !== null ) {
                foreach (['contract', 'token', 'minter', 'nft_id'] as $attr) {
                    if (isset($applicable_logic[$attr])) {
                        $attributes[$attr] = $applicable_logic[$attr];
                    }
                }
            }
        }
    }

    $fail_message = isset( $atts['fail-message'] ) ? $atts['fail-message'] : get_option("looppress_default_fail_message","<span class='dashicons dashicons-lock' style='font-size: 2.5em; width: 2.5em; display: block; margin: auto; box-sizing: border-box;'></span><br><b>You do not own the required NFT to view this content.</b><br><small>If you recently acquired the NFT, it may take up to 30 minutes for the transaction to post and be available.</small>");

    $selected_account = $_SESSION['selectedAccount'] ?? '';

    return has_membership( $selected_account, $attributes ) ? do_shortcode( $content ) : looppress_shortcode( $content, $fail_message );
}

function add_looppress_shortcode_to_posts( $content ) {
    // Get the current post ID
    $post_id = get_the_ID();
    
    // Check if the post has looppress_nft_id, looppress_minter, and looppress_token metadata
    $nft_id_metadata = get_post_meta( $post_id, 'looppress_nft_id', true );
    $minter_metadata = get_post_meta( $post_id, 'looppress_minter', true );
    $token_metadata = get_post_meta( $post_id, 'looppress_token', true );
    $contract_metadata = get_post_meta( $post_id, 'looppress_contract', true );
    // Check if the post content already contains [looppress] shortcode
    $has_looppress_shortcode = strpos( $content, '[looppress ' ) !== false;
    
    if ( $nft_id_metadata || $minter_metadata || $token_metadata || $contract_metadata ) {
        if(!$has_looppress_shortcode){
        // Add [looppress] shortcode with attributes to the post content
        $shortcode_attributes = 'nft_id="' . $nft_id_metadata . '" minter="' . $minter_metadata . '" token="' . $token_metadata . '" contract="' . $contract_metadata . '"';
        $content = '[looppress ' . $shortcode_attributes . ']' . $content . '[/looppress]';
        }
    }
    return $content;
}
add_filter( 'the_content', 'add_looppress_shortcode_to_posts' );


function has_membership($selected_account, $attributes) {
    if (empty($selected_account)) {
        return false;
    }
    // Retrieve the NFTs
    if(get_current_user_id()){
        $nfts = get_user_meta( get_current_user_id(), 'nfts', true );
        if($nfts){
            foreach ($nfts as $nft) {
                $nft_conditions = check_conditions($nft, $attributes);
                if ($nft_conditions) {
                    $user_has[] = $nft;
                }
            }
        }
    }
    // if the user is not logged in and the "allow unregistered users" is checked in settings
    else if(get_option('allow_unregistered_users') == '1'){
            if(!isset($_SESSION['looppress_nfts'])){
            $loopringApiKey = get_option('loopring_api_key');
            $loopring_account_id = $_SESSION['selectedAccountId'] ?? '';
            $url = "https://api3.loopring.io/api/v3/user/nft/balances?accountId=$loopring_account_id";
            $headers = ['Content-Type: application/json', "X-API-KEY: $loopringApiKey"];
            $nfts = [];
            $user_has = [];
            $offset = 0;
            do {
                $url_with_offset = $url . "&offset=$offset";
                $response   = curl_request($url_with_offset, $headers);
                if($response == false){
                    break;
                }
                $json = json_decode($response, true);
                $nfts = array_merge($nfts, $json['data']);

                foreach ($nfts as $nft) {
                    $nft_conditions = check_conditions($nft, $attributes);
                    if ($nft_conditions) {
                        $user_has[] = $nft;
                    }
                }

                $offset += count($json['data']);
            } while ($offset < $json['totalNum']);
            }
            else{
                foreach ($_SESSION['looppress_nfts'] as $nft) {
                    $nft_conditions = check_conditions($nft, $attributes);
                    if ($nft_conditions) {
                        $user_has[] = $nft;
                    }
                }
            }
    }

    return !empty($user_has);
}

// helper function
function curl_request($url, $headers){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode != 200) {
        return false;
    }

    return $response;
}

function check_conditions($nft, $attributes) {
    // If no conditions are set, return false.
    $attributes_filled = array_filter($attributes);
    if(empty($attributes_filled)){
        return false;
    }
    foreach ($attributes as $attr => $expression) { // Change $attribute to $attr
		switch ($attr) {
			case 'token':
				$data = $nft['tokenAddress'];
				break;
            case 'contract':
                $data = $nft['tokenAddress'];
                break;
			case 'nft_id':
				$data = $nft['nftId'];
				break;
            case 'nft':
                $data = $nft['nftId'];
                break;
			case 'minter':
				$data = $nft['minter'];
				break;
		}

        if ($expression !== '') {
            if (!evaluate_logical_expression($expression, $data)) {
                return false;
            }
        }
    }

    return true;
}

function looppress_visual_editor_shortcode() {
    ob_start(); ?>
    <button id="looppress_openEditorBtn" onclick="document.getElementById('looppress_editorModal').style.display='flex';" title="Token Gate Settings"><i class="fas fa-lock"></i></button>
    <div id="looppress_editorModal" style="display:none;width:100%">
        <div id="looppress_modalContent" style="width:90%">
            <button id="looppress_closeEditorBtn" onclick="document.getElementById('looppress_editorModal').style.display='none';">Close</button>
            <iframe id='looppress_visual_editor' src="<?php echo plugins_url('editor.html', __FILE__); ?>" width="100%" height="90%"></iframe>
        </div>
    </div>
    <script>
    window.addEventListener('message', function(event) {
        // Check if event.data is a string before calling startsWith
        if (typeof event.data === 'string') {
            if (event.data.startsWith('[looppress')) {
                console.log('Received shortcode:', event.data);
                document.getElementById('looppress_editorModal').style.display='none';
                
                // Insert the shortcode at the cursor position in the TinyMCE editor
                if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor) {
                    tinyMCE.activeEditor.execCommand('mceInsertContent', false, event.data);
                }
            }
        } else {
            //console.error('Unexpected message type:', typeof event.data);
        }
    }, false);
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('looppress_visual_editor', 'looppress_visual_editor_shortcode');






function evaluate_logical_expression($expressions, $data) {
	// Handle not operator (!)
	if (substr($expressions, 0, 1) === '!') {
		$expressions = substr($expressions, 1);  // remove the '!'
		$result = !evaluate_logical_expression($expressions, $data);
		return $result;
	}
    
    // Handle parentheses
    while (($openPos = strrpos($expressions, '(')) !== false) {
        $closePos = strpos($expressions, ')', $openPos);
        if ($closePos === false) {
            throw new Exception('Invalid expression: missing closing parenthesis');
        }

        // Evaluate innermost sub-expression
        $subExpr = substr($expressions, $openPos + 1, $closePos - $openPos - 1);
        $result = evaluate_logical_expression($subExpr, $data);

        // Replace sub-expression with result
        $expressions = substr_replace($expressions, $result ? 'true' : 'false', $openPos, $closePos - $openPos + 1);
    }

    // Evaluate logical operators (top level only)
    if (strpos($expressions, ',') !== false) {
        foreach (explode(',', $expressions) as $expr) {
            if (evaluate_logical_expression($expr, $data)) {
                return true;
            }
        }
        return false;
    } else if (strpos($expressions, '+') !== false) {
        foreach (explode('+', $expressions) as $expr) {
            if (!evaluate_logical_expression($expr, $data)) {
                return false;
            }
        }
        return true;
    } else if (strpos($expressions, '*') !== false) {
        $tokens = explode('*', $expressions);
        return substr_count($data, $tokens[0]) >= (int)$tokens[1];
    } else {
        return $expressions === 'true' ? true : ($expressions === $data);
    }
}
add_action( 'show_user_profile', 'custom_user_profile_fields' );
add_action( 'edit_user_profile', 'custom_user_profile_fields' );

function custom_user_profile_fields( $user ) {
    // Retrieve the NFTs
    $nfts = get_user_meta( $user->ID, 'nfts', true );

    // Convert the NFTs array to a readable string
    $nfts_string = '';
    if ( is_array( $nfts ) ) {
        foreach ( $nfts as $nft ) {
            // Customize this line to format the NFTs however you like
            $nfts_string .= '<div style="border 2px solid black">'.print_r( $nft, true ) . '</div>';
        }
    }
    ?>
    <h3>Extra profile information</h3>

    <table class="form-table">
        <tr>
            <th><label for="nfts">NFTs</label></th>
            <td>
                <?php echo $nfts_string; ?>
            </td>
        </tr>
    </table>
    <?php
}

// login hook to use NFT roles
function assign_role_by_nft_on_login($user_login, $user) {
    delete_user_meta($user->ID, 'nfts');
}

// Hook into the 'wp_login' action
add_action('wp_login', 'assign_role_by_nft_on_login', 10, 2);

// Increment the site-wide version number when the 'nft_roles' option is updated
function increment_version_on_nft_role_change($option_name, $old_value, $value) {
    if ('nft_roles' !== $option_name) {
        return; // Not the option we're interested in
    }
    $version = get_option('looppress_settings_version', 0);
    update_option('looppress_settings_version', $version + 1);
}
add_action('updated_option', 'increment_version_on_nft_role_change', 10, 3);

// Store the site-wide version number in user's session when they log in
function store_version_on_login($user_login, $user) {
    update_user_meta($user->ID, 'user_version', get_option('looppress_settings_version', 0));
}
add_action('wp_login', 'store_version_on_login', 10, 2);

// Compare stored version number to current site-wide version number on each page load
function check_version_on_page_load() {
    $current_user = wp_get_current_user();
    if (0 == $current_user->ID) return; // Not logged in
    $user_version = get_user_meta($current_user->ID, 'user_version', true);
    if ($user_version != get_option('looppress_settings_version', 0)) {
        wp_logout();
    }
}
add_action('init', 'check_version_on_page_load');

function clear_session_on_unload() {
    ?>
    <script>
        function clear_session() {
            jQuery.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'looppress_clear_session'
                },
                success: function() {
                    window.location.href = '<?php echo get_permalink(); ?>';
                }
            });
        }
    </script>
    <?php
}
add_action('wp_footer', 'clear_session_on_unload');


function looppress_clear_session_callback() {
    // Clear session variables
    unset($_SESSION['selectedAccount']);
    unset($_SESSION['selectedAccountId']);
    session_destroy();
    echo 'success';
    die();
}
add_action('wp_ajax_looppress_clear_session', 'looppress_clear_session_callback');
add_action('wp_ajax_nopriv_looppress_clear_session', 'looppress_clear_session_callback');

// Add AJAX endpoint to retrieve user's NFTs
add_action('wp_ajax_looppress_get_user_nfts', 'looppress_get_user_nfts');
add_action('wp_ajax_nopriv_looppress_get_user_nfts', 'looppress_get_user_nfts'); // For non-logged-in users

function looppresss_get_user_nfts() {
    // Check if the user is logged in
    if (is_user_logged_in()) {
        $user_id = get_current_user_id();
        
        // Retrieve the stored NFTs from user meta
        $nfts = get_user_meta($user_id, 'nfts', true);
        
        // Return the NFTs as JSON response
        if ($nfts) {
            wp_send_json_success($nfts);
        } else {
            wp_send_json_error('No NFTs found for the user.');
        }
    } elseif (isset($_SESSION['looppress_nfts'])) {
        $nfts = $_SESSION['looppress_nfts'];
        
        // Return the NFTs as JSON response
        if ($nfts) {
            wp_send_json_success($nfts);
        } else {
            wp_send_json_error('No NFTs found for the user.');
        }
    } else {
        wp_send_json_error('User is not logged in.');
    }
}

// Add JavaScript code to the footer
function add_nfts_retrieval_script() {
    ?>
    <script>
        function looppress_get_nfts() {
            jQuery.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php'); ?>', 
                data: {
                    action: 'looppress_get_user_nfts'
                },
                success: function(response) {
                    console.log(response);
                    if (response.success) {
                        var nfts = response.data;
                        console.log(nfts); // Log the retrieved NFTs here
                    } else {
                        console.error(response.data);
                    }
                },
                error: function(errorThrown) {
                    console.error(errorThrown);
                }
            });
        }
    </script>
    <?php
}
add_action('wp_footer', 'add_nfts_retrieval_script');


function looppress_enqueue_tinymce_plugin() {
    if (current_user_can('edit_posts') && current_user_can('edit_pages')) {
        add_filter('mce_external_plugins', 'add_looppress_tinymce_plugin');
        add_filter('mce_buttons', 'register_looppress_tinymce_button');
    }
}
add_action('admin_head', 'looppress_enqueue_tinymce_plugin');

function add_looppress_tinymce_plugin($plugin_array) {
    $plugin_array['looppress_button_script'] = plugins_url('/looppress-tinymce-plugin.js', __FILE__);
    return $plugin_array;
}

function register_looppress_tinymce_button($buttons) {
    array_push($buttons, 'looppress');
    return $buttons;
}

function looppress_add_modal_to_footer() {
    ?>
    <style>
        #looppress_editorModal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index:10000;
}
#looppress_modalContent {
    background: #fff;
    padding: 20px;
    position: relative;
}
#looppress_closeEditorBtn {
    position: absolute;
    top: 10px;
    right: 10px;
}

        </style>
    <!-- Your modal HTML here -->
    <script>
        // Listen for messages from the iframe
        var lastMessageData = null;
        var clickedElement = null;
        function sendShortcodeToIframe(element) {
            // Traverse up the DOM to find the nearest ancestor with a 'data-shortcode' attribute
            while (element && !element.dataset.shortcode) {
                element = element.parentElement;
            }
            clickedElement = element;
            // Ensure an element with a 'data-shortcode' attribute was found
            if (element && element.dataset.shortcode) {
                var shortcode = element.dataset.shortcode;

                // Display the modal
                document.getElementById('looppress_editorModal').style.display='flex';
                
                // Send the shortcode to the iframe
                var iframe = document.getElementById('looppress_visual_editor');
                iframe.contentWindow.postMessage(shortcode, '*');
        }
}
document.addEventListener('DOMContentLoaded', function() {
    // Ensure TinyMCE is loaded and editors are initialized
    if (typeof tinyMCE !== 'undefined') {
        tinyMCE.on('AddEditor', function(e) {
            e.editor.on('init', function() {
                // Get the iframe's document
                var iframeDoc = this.getDoc();

                // Add click event listener to the iframe's document
                iframeDoc.body.addEventListener('click', function(e) {
                    if(e.target.classList.contains('editableShortcode')) {
                        sendShortcodeToIframe(e.target);
                    }
                });
            });
        });
    }
});

window.addEventListener('message', function(event) {
    if (typeof event.data === 'string' && event.data.startsWith('[looppress')) {
        if (event.data === lastMessageData) {
            console.log('Ignoring duplicate message');
            lastMessageData = '';
            return;
        }
        lastMessageData = event.data;

        console.log('Received shortcode:', event.data);
        document.getElementById('looppress_editorModal').style.display = 'none';
        console.log('Received message:', event.data, 'from origin:', event.origin, 'and source:', event.source);
        
        if (typeof tinyMCE !== 'undefined' && tinyMCE.activeEditor) {
        // Generate a random color
        function getRandomColor() {
        // Minimum RGB values to ensure the color is not too dark
        var minRed = 100;
        var minGreen = 100;
        var minBlue = 100;

        // Generate random RGB values
        var red = Math.floor(Math.random() * (256 - minRed) + minRed).toString(16);
        var green = Math.floor(Math.random() * (256 - minGreen) + minGreen).toString(16);
        var blue = Math.floor(Math.random() * (256 - minBlue) + minBlue).toString(16);

        // Ensure each color component is two digits
        if (red.length === 1) red = '0' + red;
        if (green.length === 1) green = '0' + green;
        if (blue.length === 1) blue = '0' + blue;

        return '#' + red + green + blue;
    }

    var randomColor = getRandomColor();

     // Check if clickedElement is not null
     var escapedData = event.data.replace(/"/g, '&quot;');
     if (clickedElement) {
        // Update the data-shortcode attribute of the clicked element
        clickedElement.setAttribute('data-shortcode', escapedData);

        // Reset clickedElement to null
        clickedElement = null;
    }
    else{
        // Insert the shortcode and highlighted text into the editor
    tinyMCE.activeEditor.execCommand('mceInsertContent', false, 
    '<div contenteditable="false" data-shortcode="'+escapedData+'" style="border-bottom:2px solid '+randomColor+';border-top:2px solid '+randomColor+'">' +
        '<span style="background-color: ' + randomColor + ';"><button contenteditable="false" class="editableShortcode" style="background-color:'+randomColor+'"><i class="editableShortcode dashicons dashicons-lock"></button><br></span>' +
        '<div contenteditable="true">Token Gated Content goes HERE</div>' +
        '<span style="background-color: ' + randomColor + ';"><button contenteditable="false" class="editableShortcode" style="background-color:'+randomColor+'"><i class="editableShortcode dashicons dashicons-lock"></button><br></span>' +
    '</div><p>&nbsp;</p>'
    );
    }
    

    }

    }
}, true);



    </script>
    <div id="looppress_editorModal" style="display:none;width:100%">
        <div id="looppress_modalContent" style="width:90%">
            <button id="looppress_closeEditorBtn" onclick="document.getElementById('looppress_editorModal').style.display='none';">Close</button>
            <iframe id='looppress_visual_editor' src="<?php echo plugins_url('editor.html', __FILE__); ?>" width="100%" height="90%"></iframe>
        </div>
    </div>
    <?php
}
add_action('admin_print_footer_scripts', 'looppress_add_modal_to_footer');

function strip_out_shortcode_junk($content) {
    // Use a regular expression to match the structure you've added
    $pattern = '/<div .*?data-shortcode=\\\"(.*?)\\\".*?>.*?<div contenteditable=\\\"true\\\">(.*?)<\/div>.*?<\/div>/s';

    // Replace the matched structure with just the shortcode wrapped around the content
    $replacement = '$1$2[/looppress]'; // Assuming [looppress] is the opening tag and [/looppress] is the closing tag

    $content = preg_replace($pattern, $replacement, $content);

    return $content;
}

add_filter('content_save_pre', 'strip_out_shortcode_junk');

function restore_shortcode_to_div_tinymce($content) {
    // Use a regular expression to match the shortcode structure
    $pattern = '/\[looppress schedule=\'(.*?)\'\](.*?)\[\/looppress\]/';
    

    // Generate a random color
    function getRandomColor() {
        $minRed = 100;
        $minGreen = 100;
        $minBlue = 100;

        $red = str_pad(dechex(mt_rand($minRed, 255)), 2, '0', STR_PAD_LEFT);
        $green = str_pad(dechex(mt_rand($minGreen, 255)), 2, '0', STR_PAD_LEFT);
        $blue = str_pad(dechex(mt_rand($minBlue, 255)), 2, '0', STR_PAD_LEFT);

        return '#' . $red . $green . $blue;
    }

    // Callback function for preg_replace_callback
    function replace_shortcode($matches) {
        $randomColor = getRandomColor();
        // Encode the JSON string
        $encodedJson = htmlspecialchars($matches[1], ENT_QUOTES, 'UTF-8');
        return '<div contenteditable="false" data-shortcode="[looppress schedule=\'' . $encodedJson . '\']" style="border-bottom:2px solid ' . $randomColor . ';border-top:2px solid ' . $randomColor . '">' .
            '<span style="background-color: ' . $randomColor . ';"><button contenteditable="false" class="editableShortcode" style="background-color:' . $randomColor . '"><i class="editableShortcode dashicons dashicons-lock"></i></button><br></span>' .
            '<div contenteditable="true">' . $matches[2] . '</div>' .  // This is where the content should be placed
            '<span style="background-color: ' . $randomColor . ';"><button contenteditable="false" class="editableShortcode" style="background-color:' . $randomColor . '"><i class="editableShortcode dashicons dashicons-lock"></i></button><br></span>' .
        '</div><p>&nbsp;</p>';
    }
    
    

    if (is_array($content)) {
        $content = implode(" ", $content);
    }

    $content = html_entity_decode($content);

    if (preg_match($pattern, $content)) {
        error_log("Match found!");
    } else {
        error_log("No match found.");
    }

    $content = preg_replace_callback($pattern, 'replace_shortcode', $content);

    return $content;
}

add_filter('content_edit_pre', 'restore_shortcode_to_div_tinymce');

