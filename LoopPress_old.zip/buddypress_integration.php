<?php

define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', true );

// Add custom metadata to BuddyBoss groups upon creation or update.
function add_custom_nft_metadata_to_group( $group_id, $member, $group ) {
    // Check if the custom attributes are set in the POST request.
    if ( isset( $_POST['contract'] ) ) {
        groups_update_groupmeta( $group_id, 'contract', sanitize_text_field( $_POST['contract'] ) );
    }
    if ( isset( $_POST['minter'] ) ) {
        groups_update_groupmeta( $group_id, 'minter', sanitize_text_field( $_POST['minter'] ) );
    }
    if ( isset( $_POST['nft'] ) ) {
        groups_update_groupmeta( $group_id, 'nft', sanitize_text_field( $_POST['nft'] ) );
    }
}

// Hook the function to the group creation and update actions.
add_action( 'groups_update_group', 'add_custom_nft_metadata_to_group', 10, 3 );

function looppress_group_tab_screen() {
    add_action( 'bp_template_content', 'looppress_group_tab_content' );
    bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'groups/single/plugins' ) );
}


function looppress_group_tab_content() {
    // Get the current group ID.
    $group_id = bp_get_current_group_id();

    // Check if the form is submitted.
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        // Check if the custom attributes are set in the POST request.
        if ( isset( $_POST['contract'] ) ) {
            groups_update_groupmeta( $group_id, 'contract', sanitize_text_field( $_POST['contract'] ) );
        }
        if ( isset( $_POST['minter'] ) ) {
            groups_update_groupmeta( $group_id, 'minter', sanitize_text_field( $_POST['minter'] ) );
        }
        if ( isset( $_POST['nft'] ) ) {
            groups_update_groupmeta( $group_id, 'nft', sanitize_text_field( $_POST['nft'] ) );
        }
        // Add a success message.
        bp_core_add_message( 'Settings saved successfully.', 'success' );
    }

    // Fetch the saved values (if any) from the group metadata.
    $contract = $group_id ? groups_get_groupmeta( $group_id, 'contract', true ) : '';
    $minter   = $group_id ? groups_get_groupmeta( $group_id, 'minter', true ) : '';
    $nft      = $group_id ? groups_get_groupmeta( $group_id, 'nft', true ) : '';

    // Output the custom fields.
    ?>
    <form action="" method="post">
        <h4>LoopPress Settings</h4>
        <br>
        <label for="contract">Contract</label>
        <input type="text" name="contract" id="contract" value="<?php echo esc_attr( $contract ); ?>">
        <br>
        <label for="minter">Minter</label>
        <input type="text" name="minter" id="minter" value="<?php echo esc_attr( $minter ); ?>">
        <br>
        <label for="nft">NFT</label>
        <input type="text" name="nft" id="nft" value="<?php echo esc_attr( $nft ); ?>">
        <br>
        <input type="submit" value="Save Settings">
    </form>
    <?php
}



function looppress_register_group_tab() {
    if ( bp_is_group() ) {
        bp_core_new_subnav_item( array(
            'name'            => 'LoopPress',
            'slug'            => 'looppress',
            'parent_url'      => bp_get_group_permalink( groups_get_current_group() ),
            'parent_slug'     => bp_get_current_group_slug(),
            'screen_function' => 'looppress_group_tab_screen',
            'position'        => 75,
            'user_has_access' => bp_current_user_can( 'bp_moderate' ),
            'item_css_id'     => 'group-looppress'
        ) );
    }
}
add_action( 'bp_setup_nav', 'looppress_register_group_tab', 100 );


function looppress_gate_groups_access() {
    // Check if we're viewing a single group.
    if ( bp_is_group() ) {
        // Fetch the group's minter, nft, and contract attributes from group meta.
        $group_id = bp_get_current_group_id();
        $group_minter = groups_get_groupmeta( $group_id, 'minter', true );
        $group_nft = groups_get_groupmeta( $group_id, 'nft', true );
        $group_contract = groups_get_groupmeta( $group_id, 'contract', true );
        $has_access = true;
        if($group_minter || $group_nft || $group_contract){
            $has_access = false;
            // Get the current user.
            $current_user = wp_get_current_user();

            // Fetch the user's NFTs from user meta (assuming it's stored as an array).
            $user_nfts = get_user_meta( $current_user->ID, 'nfts', true );

            // Check each user's NFT against the group's attributes.
            foreach ( $user_nfts as $nft ) {
                if ( check_conditions( $nft, array( 'minter' => $group_minter, 'nft' => $group_nft, 'contract' => $group_contract ) ) ) {
                    $has_access = true;
                    break;
                }
            }
        }
        if(bp_current_user_can( 'bp_moderate' )){
            $has_access = true;
        }

        // If the user doesn't have access, redirect them with a message.
        if ( ! $has_access ) {
            bp_core_add_message( 'Sorry, you do not have access to this group based on your NFTs.', 'error' );
            bp_core_redirect( bp_get_groups_directory_permalink() );
        }
    }
}

add_action( 'bp_template_redirect', 'looppress_gate_groups_access' );
