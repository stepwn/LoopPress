<?php
/* function looppress_enqueue_medium_editor() {
    // Enqueue MediumEditor CSS from CDN
    wp_enqueue_style('medium-editor-css', 'https://cdnjs.cloudflare.com/ajax/libs/medium-editor/5.23.3/css/medium-editor.min.css');

    // Enqueue MediumEditor theme CSS (you can choose other themes if you prefer)
    wp_enqueue_style('medium-editor-theme-default', 'https://cdnjs.cloudflare.com/ajax/libs/medium-editor/5.23.3/css/themes/default.min.css');

    // Enqueue MediumEditor JS from CDN
    wp_enqueue_script('medium-editor-js', 'https://cdnjs.cloudflare.com/ajax/libs/medium-editor/5.23.3/js/medium-editor.min.js', array(), false, true);

    // Enqueue your custom JS
    wp_enqueue_script('medium-editor-custom-js', plugins_url('medium-plugin.js', __FILE__), array('medium-editor-js'), false, true);
}
add_action('wp_enqueue_scripts', 'looppress_enqueue_medium_editor'); */